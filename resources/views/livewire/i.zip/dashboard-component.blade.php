<div>
    {{-- If your happiness depends on money, you will never be happy with yourself. --}}
</div>
